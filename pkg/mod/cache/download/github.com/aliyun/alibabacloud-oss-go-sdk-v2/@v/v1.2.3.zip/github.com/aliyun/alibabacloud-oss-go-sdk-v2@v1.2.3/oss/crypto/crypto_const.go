package crypto

// encryption Algorithm
const (
	RsaCryptoWrap    string = "RSA/NONE/PKCS1Padding"
	KmsAliCryptoWrap string = "KMS/ALICLOUD"
	AesCtrAlgorithm  string = "AES/CTR/NoPadding"
)
