package optdec

type context = Context
